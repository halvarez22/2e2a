
import { GoogleGenAI } from "@google/genai";
import { COMPANY_CONTEXT } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

/**
 * Uses Model Context Protocol (MCP) logic by injecting dynamic corporate context 
 * into the system instructions for every interaction.
 */
export const sendMessageToAI = async (message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.parts[0].text }] })),
        { role: 'user', parts: [{ text: message }] }
      ],
      config: {
        systemInstruction: COMPANY_CONTEXT,
        temperature: 0.7,
        topP: 0.95,
        maxOutputTokens: 500,
      },
    });

    return response.text || "Lo siento, tuve un problema procesando tu solicitud.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "En este momento nuestro asistente ejecutivo está fuera de línea. Por favor, contáctanos vía WhatsApp.";
  }
};
