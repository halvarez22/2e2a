
export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  details: string[];
}

export interface ContactFormData {
  name: string;
  email: string;
  company: string;
  message: string;
  serviceInterest: string;
}

export interface QuoteFormData extends ContactFormData {
  projectScope: string;
  estimatedBudget: string;
  timeline: string;
}

export enum ChatRole {
  USER = 'user',
  MODEL = 'model'
}

export interface ChatMessage {
  role: ChatRole;
  text: string;
  timestamp: Date;
}
