
import { ServiceItem } from './types';

export const COMPANY_NAME = "2e2a";
export const COMPANY_TAGLINE = "Innovación en Logística, Seguridad y Calidad de Software";

export const SERVICES: ServiceItem[] = [
  {
    id: 'logistics',
    title: 'Logística Global Inteligente',
    description: 'Optimización de cadena de suministro con estándares LSA (Logistics Services Alliance).',
    icon: 'fa-ship',
    details: ['Fletes Internacionales', 'Despacho Aduanero', 'Consolidación de Carga', 'Seguimiento en Tiempo Real']
  },
  {
    id: 'sqa',
    title: 'Software Quality Assurance (SQA)',
    description: 'Aseguramiento de calidad técnica bajo estándares internacionales rigurosos.',
    icon: 'fa-shield-check',
    details: ['Pruebas Automatizadas', 'QA Consulting', 'Performance Testing', 'DevSecOps Integration']
  },
  {
    id: 'iso27034',
    title: 'Seguridad ISO/IEC 27034',
    description: 'Implementación de marcos de seguridad para el ciclo de vida de las aplicaciones.',
    icon: 'fa-lock',
    details: ['ASMP Management', 'Security Assessment', 'Application Security Framework', 'Compliance Audit']
  },
  {
    id: 'saas',
    title: 'Arquitectura Cloud & SaaS',
    description: 'Desarrollo escalable utilizando Firebase, Vercel y microservicios modernos.',
    icon: 'fa-cloud',
    details: ['Migración Cloud', 'Infraestructura como Código', 'SaaS Multi-tenant', 'Data Analytics']
  }
];

export const COMPANY_CONTEXT = `
  Eres el asistente inteligente de 2e2a. 
  2e2a es una empresa líder que fusiona la logística global (aliada a thelsa.com) con tecnología de vanguardia.
  Especialidades: 
  - Logística Internacional (Fletes, Aduanas).
  - Software Quality Assurance (SQA).
  - Seguridad en Aplicaciones bajo norma ISO/IEC 27034.
  - Desarrollo de SaaS escalable (Firebase + Vercel).
  El tono debe ser: Ejecutivo, Profesional, Comercial, Resolutivo y Tecnológico.
  Si el cliente pregunta por cotizaciones, invítalo a usar el formulario de la página.
`;

export const CONTACT_INFO = {
  email: 'contacto@2e2a.com',
  whatsapp: 'https://wa.me/1234567890',
  linkedin: 'https://linkedin.com/company/2e2a'
};
