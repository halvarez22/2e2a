
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-blue-600/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-slate-400/10 rounded-full blur-[100px]"></div>

      <div className="container mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <h2 className="text-blue-500 font-bold tracking-[0.3em] uppercase mb-4 text-sm animate-bounce">Logística + SQA + Seguridad</h2>
          <h1 className="text-6xl md:text-8xl font-black mb-8 leading-tight">
            Elevamos su <br />
            <span className="gradient-text">Ecosistema Global</span>
          </h1>
          <p className="text-xl text-slate-400 mb-10 max-w-lg leading-relaxed">
            Soluciones integrales de logística inteligente y aseguramiento de calidad de software bajo estándares ISO/IEC 27034. 
            El puente entre la eficiencia operativa y la seguridad digital.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="#contacto" className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-center transition-all transform hover:-translate-y-1">
              Iniciar Proyecto
            </a>
            <a href="#servicios" className="px-8 py-4 border border-slate-700 hover:border-slate-500 rounded-xl font-bold text-center transition-all">
              Explorar Servicios
            </a>
          </div>
          
          <div className="mt-12 flex items-center gap-8 grayscale opacity-50">
            <span className="text-xs uppercase tracking-widest font-semibold">Certificados en:</span>
            <div className="flex gap-4 items-center">
              <span className="text-lg font-bold">SQA</span>
              <span className="text-lg font-bold">ISO 27034</span>
              <span className="text-lg font-bold">LSA</span>
            </div>
          </div>
        </div>

        <div className="relative hidden lg:block">
            <div className="rounded-3xl overflow-hidden shadow-2xl shadow-blue-500/10 border border-slate-800 rotate-2 hover:rotate-0 transition-transform duration-700">
                <img src="https://picsum.photos/800/600?grayscale" alt="Executive Workspace" className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -left-6 glass-morphism p-6 rounded-2xl shadow-xl max-w-xs border border-blue-500/30">
                <p className="text-sm italic font-medium">"2e2a transformó nuestra cadena de suministro con un rigor técnico sin precedentes en el mercado."</p>
                <div className="mt-4 flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-slate-700"></div>
                    <div>
                        <p className="text-xs font-bold">Director de Operaciones</p>
                        <p className="text-[10px] text-slate-500 uppercase">Fortune 500 Partner</p>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
