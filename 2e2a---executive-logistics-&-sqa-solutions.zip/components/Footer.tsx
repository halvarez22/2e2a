
import React from 'react';
import { COMPANY_NAME, CONTACT_INFO } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 py-16">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-lg">2</div>
              <span className="text-2xl font-black text-white">{COMPANY_NAME}</span>
            </div>
            <p className="text-slate-500 max-w-sm mb-8">
              Líderes en integración de procesos logísticos globales y aseguramiento de calidad técnica bajo estándares internacionales de seguridad.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full border border-slate-800 flex items-center justify-center hover:border-blue-500 hover:text-blue-500 transition-all">
                <i className="fa-brands fa-linkedin-in"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-slate-800 flex items-center justify-center hover:border-blue-500 hover:text-blue-500 transition-all">
                <i className="fa-brands fa-twitter"></i>
              </a>
              <a href={CONTACT_INFO.whatsapp} target="_blank" className="w-10 h-10 rounded-full border border-slate-800 flex items-center justify-center hover:border-green-500 hover:text-green-500 transition-all">
                <i className="fa-brands fa-whatsapp"></i>
              </a>
            </div>
          </div>

          <div>
            <h5 className="font-bold text-white mb-6 uppercase tracking-widest text-xs">Servicios</h5>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li><a href="#" className="hover:text-blue-400">Logística Global</a></li>
              <li><a href="#" className="hover:text-blue-400">SQA Consulting</a></li>
              <li><a href="#" className="hover:text-blue-400">ISO/IEC 27034</a></li>
              <li><a href="#" className="hover:text-blue-400">Desarrollo SaaS</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-white mb-6 uppercase tracking-widest text-xs">Compañía</h5>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li><a href="#" className="hover:text-blue-400">Sobre Nosotros</a></li>
              <li><a href="#" className="hover:text-blue-400">Alianza LSA</a></li>
              <li><a href="#" className="hover:text-blue-400">Soporte Ejecutivo</a></li>
              <li><a href="#" className="hover:text-blue-400">Privacidad</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col md:row justify-between items-center gap-4 text-xs text-slate-600 font-medium">
          <p>© 2024 2e2a Global Solutions. Todos los derechos reservados.</p>
          <div className="flex gap-8">
            <span className="flex items-center gap-1"><i className="fa-solid fa-shield-halved text-blue-900"></i> ISO 27034 Compliance</span>
            <span className="flex items-center gap-1"><i className="fa-solid fa-check-double text-blue-900"></i> SQA Verified</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
