
import React from 'react';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <section id="servicios" className="py-24 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-black mb-4">Nuestros Pilares de <span className="text-blue-500">Valor</span></h2>
          <p className="text-slate-400 max-w-2xl mx-auto">Basados en la excelencia operativa de LSA y la robustez de los marcos de seguridad internacionales.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.map((service) => (
            <div key={service.id} className="group bg-slate-950 p-8 rounded-3xl border border-slate-800 hover:border-blue-500/50 transition-all duration-500 transform hover:-translate-y-2">
              <div className="w-14 h-14 bg-blue-600/10 rounded-2xl flex items-center justify-center text-blue-500 text-2xl mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all">
                <i className={`fa-solid ${service.icon}`}></i>
              </div>
              <h3 className="text-xl font-bold mb-4">{service.title}</h3>
              <p className="text-slate-400 text-sm mb-6 leading-relaxed">{service.description}</p>
              <ul className="space-y-3">
                {service.details.map((detail, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                    <i className="fa-solid fa-check text-blue-500"></i>
                    {detail}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
