
import React, { useState, useEffect } from 'react';
import { COMPANY_NAME } from '../constants';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-slate-950/90 backdrop-blur-md py-4 shadow-2xl border-b border-slate-800' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          {/* Logo Placeholder - Should be at C:\2e2a_app\public\images\logo.png */}
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-xl">2</div>
          <span className="text-2xl font-extrabold tracking-tighter text-white">
            {COMPANY_NAME}
          </span>
        </div>
        
        <div className="hidden md:flex items-center space-x-10 text-sm font-medium uppercase tracking-widest text-slate-300">
          <a href="#inicio" className="hover:text-blue-400 transition-colors">Inicio</a>
          <a href="#servicios" className="hover:text-blue-400 transition-colors">Servicios</a>
          <a href="#normativa" className="hover:text-blue-400 transition-colors">Normativa</a>
          <a href="#contacto" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full transition-all">Cotizar</a>
        </div>

        <button className="md:hidden text-2xl">
          <i className="fa-solid fa-bars"></i>
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
