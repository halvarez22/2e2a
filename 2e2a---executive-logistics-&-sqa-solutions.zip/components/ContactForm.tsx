
import React, { useState } from 'react';
import { SERVICES, CONTACT_INFO } from '../constants';

const ContactForm: React.FC = () => {
  const [formType, setFormType] = useState<'contact' | 'quote'>('contact');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <section id="contacto" className="py-24 bg-slate-950 relative overflow-hidden">
      <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-16 relative z-10">
        <div>
          <h2 className="text-4xl md:text-5xl font-black mb-6 italic tracking-tight">Construyamos el Futuro de su Empresa</h2>
          <p className="text-slate-400 text-lg mb-12">Estamos listos para implementar soluciones SQA de alto impacto o gestionar su logística global con eficiencia 2e2a.</p>
          
          <div className="space-y-8">
            <div className="flex items-center gap-6">
              <div className="w-12 h-12 bg-blue-600/20 rounded-full flex items-center justify-center text-blue-500">
                <i className="fa-solid fa-envelope"></i>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase font-bold tracking-widest">Email Corporativo</p>
                <p className="text-xl font-medium">{CONTACT_INFO.email}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-6">
              <div className="w-12 h-12 bg-green-600/20 rounded-full flex items-center justify-center text-green-500">
                <i className="fa-brands fa-whatsapp"></i>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase font-bold tracking-widest">Atención Ejecutiva WhatsApp</p>
                <a href={CONTACT_INFO.whatsapp} target="_blank" className="text-xl font-medium hover:text-green-400">+52 (XXX) XXX XXXX</a>
              </div>
            </div>
          </div>

          <div className="mt-16 p-8 rounded-3xl bg-blue-600/5 border border-blue-500/20">
            <h4 className="font-bold mb-2">Compromiso ISO/IEC 27034</h4>
            <p className="text-sm text-slate-400">Toda la información proporcionada es tratada bajo estrictos estándares de seguridad y confidencialidad.</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-8 md:p-12 rounded-[2rem] shadow-2xl">
          <div className="flex gap-4 mb-8 p-1 bg-slate-950 rounded-2xl">
            <button 
              onClick={() => setFormType('contact')}
              className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${formType === 'contact' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Contacto
            </button>
            <button 
              onClick={() => setFormType('quote')}
              className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${formType === 'quote' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Cotización
            </button>
          </div>

          {submitted ? (
            <div className="h-[400px] flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 bg-green-600/20 rounded-full flex items-center justify-center text-green-500 text-4xl mb-6">
                <i className="fa-solid fa-circle-check"></i>
              </div>
              <h3 className="text-2xl font-bold mb-2">Solicitud Recibida</h3>
              <p className="text-slate-400">Un ejecutivo de 2e2a se pondrá en contacto en menos de 24 horas.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Nombre Completo</label>
                  <input required type="text" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 outline-none transition-all" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Correo Corporativo</label>
                  <input required type="email" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 outline-none transition-all" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase">Servicio de Interés</label>
                <select className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 outline-none transition-all appearance-none">
                  {SERVICES.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
                </select>
              </div>

              {formType === 'quote' && (
                <div className="grid md:grid-cols-2 gap-6 animate-fadeIn">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Presupuesto Estimado</label>
                    <input type="text" placeholder="USD" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 outline-none transition-all" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Timeline del Proyecto</label>
                    <input type="text" placeholder="Meses" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 outline-none transition-all" />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase">Descripción de Requerimientos</label>
                <textarea rows={4} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:border-blue-500 outline-none transition-all resize-none"></textarea>
              </div>

              <button type="submit" className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2">
                Enviar Solicitud <i className="fa-solid fa-paper-plane text-xs"></i>
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default ContactForm;
