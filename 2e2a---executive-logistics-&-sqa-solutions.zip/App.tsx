
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';
import Chatbot from './components/Chatbot';

const App: React.FC = () => {
  return (
    <div className="min-h-screen selection:bg-blue-600 selection:text-white">
      <Navbar />
      
      <main>
        <Hero />
        
        {/* Compliance Section (ISO 27034 & SQA Focus) */}
        <section id="normativa" className="py-20 bg-slate-950">
          <div className="container mx-auto px-6">
            <div className="glass-morphism p-12 rounded-[3rem] border border-blue-500/20 grid lg:grid-cols-3 gap-12 items-center">
              <div className="lg:col-span-2">
                <h2 className="text-3xl font-black mb-6">Rigurosidad Normativa: ISO/IEC 27034 & SQA</h2>
                <p className="text-slate-400 mb-8 leading-relaxed">
                  En 2e2a, no solo entregamos software o servicios logísticos; garantizamos integridad. 
                  Apegándonos al estándar <strong>ISO/IEC 27034</strong>, implementamos el Marco de Seguridad de Aplicaciones (ASMP) 
                  en cada fase del desarrollo. Nuestro compromiso con el <strong>SQA (Software Quality Assurance)</strong> asegura 
                  que cada solución SaaS en Vercel y Firebase sea resiliente, escalable y segura.
                </p>
                <div className="flex flex-wrap gap-4">
                  <div className="bg-slate-900/50 px-6 py-3 rounded-2xl border border-slate-800 text-sm font-bold flex items-center gap-3">
                    <i className="fa-solid fa-shield-virus text-blue-500"></i> DevSecOps Integrado
                  </div>
                  <div className="bg-slate-900/50 px-6 py-3 rounded-2xl border border-slate-800 text-sm font-bold flex items-center gap-3">
                    <i className="fa-solid fa-vial-circle-check text-blue-500"></i> SQA Continuous Testing
                  </div>
                </div>
              </div>
              <div className="flex justify-center">
                <div className="w-48 h-48 border-4 border-blue-600 rounded-full flex flex-col items-center justify-center animate-spin-slow">
                   <span className="text-4xl font-black italic">100%</span>
                   <span className="text-[10px] font-bold uppercase tracking-tighter">Compliance</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Services />
        <ContactForm />
      </main>

      <Footer />
      <Chatbot />

      {/* Tailwind extra animations style */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out forwards;
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 12s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default App;
